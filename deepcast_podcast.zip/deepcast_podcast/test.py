import pandas as pd


pd.read_parquet('DOAC/Evy Poumpouras/summaries/secret-agent-send-your-children-to-a-village-how-to-detect-a-lie-instantly-the-eye-contact-trick-i-learnt-from-12-years-as-a-secret-service-agent-evy-poumpouras_combined.parquet')
