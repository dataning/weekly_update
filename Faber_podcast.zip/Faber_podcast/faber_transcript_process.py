import pandas as pd

# Read the .txt file into a DataFrame
file_path = "Faber_Damodaran_podcast.txt"  # Replace with the path to your .txt file
df = pd.read_csv(file_path, sep="\t")

def group_consecutive_answers(df):
    # Initialize a new list to store the grouped data
    grouped_data = []
    
    # Temporary variables to store ongoing grouped answers
    current_speaker = None
    current_answer = ""
    
    # Iterate through the DataFrame rows
    for i, row in df.iterrows():
        transcript_type = row['transcriptComponentTypeName']
        
        # Check if the current row is an "Answer"
        if transcript_type == 'Answer':
            if current_speaker == row['transcriptPersonName']:
                # If the same speaker continues with another answer, append the text
                current_answer += " " + row['componentText']
            else:
                # If we switch speakers or start with a new answer, save the previous one
                if current_speaker:
                    grouped_data.append({
                        'transcriptPersonName': current_speaker,
                        'componentText': current_answer,
                        'tickerSymbol': row['tickerSymbol'],
                        'transcriptComponentTypeName': 'Answer'
                    })
                
                # Reset the speaker and answer
                current_speaker = row['transcriptPersonName']
                current_answer = row['componentText']
        else:
            # If it's not an answer, first append any ongoing answer
            if current_speaker:
                grouped_data.append({
                    'transcriptPersonName': current_speaker,
                    'componentText': current_answer,
                    'tickerSymbol': row['tickerSymbol'],
                    'transcriptComponentTypeName': 'Answer'
                })
                current_speaker = None
                current_answer = ""
            
            # Add non-answer rows directly to the grouped data
            grouped_data.append({
                'transcriptPersonName': row['transcriptPersonName'],
                'componentText': row['componentText'],
                'tickerSymbol': row['tickerSymbol'],
                'transcriptComponentTypeName': row['transcriptComponentTypeName']
            })
    
    # After the loop, append any remaining answer
    if current_speaker and current_answer:
        grouped_data.append({
            'transcriptPersonName': current_speaker,
            'componentText': current_answer,
            'tickerSymbol': row['tickerSymbol'],
            'transcriptComponentTypeName': 'Answer'
        })

    # Convert the grouped data back into a DataFrame
    grouped_df = pd.DataFrame(grouped_data)
    
    return grouped_df

# Example usage:
# Assuming your DataFrame is called `df`
grouped_df = group_consecutive_answers(df)
print(grouped_df)

